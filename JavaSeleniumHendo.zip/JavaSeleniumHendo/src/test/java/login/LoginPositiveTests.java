package login;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import pages.BasePage;
import pages.HomePage;
import pages.LoginPage;

import java.time.Duration;

public class LoginPositiveTests   {


    public static void main(String[] args) throws InterruptedException {
        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));



        driver.get("http://automationexercise.com");


        HomePage homePageLogic = new HomePage(driver);
        homePageLogic.verificationHomePage();

        LoginPage loginPageLogic = new LoginPage(driver);
        Thread.sleep(2000);
        loginPageLogic.loginButtonClick();
        loginPageLogic.visibleNewUserSignupText();
        loginPageLogic.enterUserName("Henrik");
        loginPageLogic.enterEmailAdress("hovhanniyan-2001@mail.ru");
        loginPageLogic.SignUpButtonClick();
        loginPageLogic.visibleEnterAccountInformation();
        loginPageLogic.fillTitle();
        loginPageLogic.enterUserName("Henrik");
        loginPageLogic.enterEmailAdress("hovhanniyan-2001@mail.ru");
        loginPageLogic.enterPassword("hendo11111111");
        loginPageLogic.selectMonth();
        loginPageLogic.selectYear();







    }
}

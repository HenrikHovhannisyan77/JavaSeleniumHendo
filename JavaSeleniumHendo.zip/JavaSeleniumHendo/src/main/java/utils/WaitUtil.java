package utils;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchWindowException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class WaitUtil {
    static Duration TIMEOUT = Duration.ofSeconds(10);

    public static void waitElementLocatedBecomeVisible(WebDriver driver, By by, boolean exceptionOnFail){//es function-y  nra hamar enq grel,vor ete exception uzi qci ignor gna aysinqn chqci eli
        Wait<WebDriver> wait;//es zut syntaxa,WebDriveric object enq stexcel
        if (exceptionOnFail){//ete stex false tanq kmtni esle , stex ete false enq talis sarquma explicit  wait tipi object  u amenanerqevum arden mer waity vor grumenq explicit wait tipova vercnelu,isk vor tanq true kmtni Fluenq wait tipi object kstexci
            wait=new WebDriverWait(driver,TIMEOUT);//timeout asuma inchqan jamank spasi
        }else {
            wait=new FluentWait<>(driver).withTimeout(TIMEOUT).pollingEvery(Duration.ofSeconds(1)).ignoring(NoSuchWindowException.class);//polling every aysiqn qani varkyany mek check ani// vor grelenq class- senca greladzevy,inqy uzuma vor class tipi lini ,//TimeOutExceptiony chi linum ignore anel
        }
        wait.until(ExpectedConditions.visibilityOfElementLocated(by));
        System.out.println("\n" + by + " element is visible");


    }
    public static void waitElementLocatedBecomeClickable(WebDriver driver,By by){
        WebDriverWait wait = new WebDriverWait(driver,TIMEOUT);//syntaxa,WebDriveric object enq stexcel
        wait.until(ExpectedConditions.visibilityOfElementLocated(by));
        wait.until(ExpectedConditions.elementToBeClickable(by));

        System.out.println("\n" + by + "Element is visible and Clickable");

    }


    public static void waitElementLocatedBecomeInVisible(WebDriver driver,By by){
        WebDriverWait wait = new WebDriverWait(driver,TIMEOUT);
        wait.until(ExpectedConditions.invisibilityOfElementLocated(by));

    }
    public static void waitFrameToBecomeVisibleAndSwitchToIt(WebDriver driver,By by){
        WebDriverWait wait = new WebDriverWait(driver,TIMEOUT);
        wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(by));

    }

    public static void waitAlertToBeVisible(WebDriver driver){
        WebDriverWait wait = new WebDriverWait(driver,TIMEOUT);
        wait.until(ExpectedConditions.alertIsPresent());
    }
}

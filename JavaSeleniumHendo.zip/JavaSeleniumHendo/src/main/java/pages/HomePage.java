package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class HomePage extends BasePage {
WebDriver driver;



    //Constructor that will be automatically called as soon as the object of the class is created
    public HomePage(WebDriver driver){
        super(driver);
    }
    String expectedUrl ="http://automationexercise.com";


    private static final By LOGIN_BUTTON_LOCATOR = By.id("login");

    //Locator for login button
    By LoginBtn = By.id("login");

    public void verificationHomePage(){

         String actualUrl = driver.getCurrentUrl();

         if (expectedUrl.equals(actualUrl)){
             System.out.println("You are in HomePage!");
         }


    }
    //Method to click login button
    public void clickLoginButton() {
        clickOnWebElement(LOGIN_BUTTON_LOCATOR);
    }
}
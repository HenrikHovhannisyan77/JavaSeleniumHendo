package pages;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import utils.WaitUtil;

import java.time.Duration;

public class LoginPage extends BasePage{

WebDriver driver;


    //Constructor that will be automatically called as soon as the object of the class is created
    public LoginPage(WebDriver driver) {
        super(driver);
    }
    private static final By signUpLoginButton = By.cssSelector("a[href='i[class='fa fa-lock']']");

    private static final By userNameField = By.cssSelector("input[type='text']");
    private static final By passwordField = By.cssSelector("input[type='password']");
    private static final By emailAdressField = By.xpath("//input[@data-qa='signup-email']");
    private static final By signUpButton = By.cssSelector("button[data-qa='signup-button']");
    private static final By newUserSignupText = By.xpath("//h2[text()='New User Signup']");
    private static final By enterAccountInformationText = By.xpath("//b[text()='Enter Account Information']");
    private static final By titleRadioButton = By.cssSelector("input[id='id_gender1']");
    private  final WebElement day = driver.findElement(By.cssSelector("select[data-qa='days']"));
    private final WebElement month = driver.findElement(By.cssSelector("select[data-qa='months']"));
    private  final WebElement year = driver.findElement(By.cssSelector("select[data-qa='years']"));
    private static final By newletter = By.cssSelector("input[id='newsletter']");
    private static final By optin = By.cssSelector("input[id='optin']");
    private static final By firstName = By.cssSelector("input[id='first_name']");
    private static final By lastName = By.cssSelector("input[id='last_name']");
    private static final By company = By.cssSelector("input[id='company']");
    private static final By address1 = By.cssSelector("input[id='address1']");
    private static final By address2 = By.cssSelector("input[id='address2']");
    private final WebElement country = driver.findElement(By.cssSelector("select[id='country']"));
    private static final By state = By.cssSelector("input[id='state']");
    private static final By city = By.cssSelector("input[id='city']");
    private static final By zipcode = By.cssSelector("input[id='zipcode']");
    private static final By mobileNumber = By.cssSelector("input[id='mobile_number']");
    private static final By creatAccountButton =By.cssSelector("button[data-qa='create-account']");








    public  void loginButtonClick(){
       // WaitUtil.waitElementLocatedBecomeClickable(driver,signUpLoginButton);
        getWebElement(signUpLoginButton).click();

    }
    public void enterUserName(String text){
        enterText(userNameField,text);

    }
    public void enterPassword(String text){
        enterText(passwordField,text);
    }
    public void enterEmailAdress(String text){
        enterText(emailAdressField,text);
    }
    public  void SignUpButtonClick(){
        WaitUtil.waitElementLocatedBecomeClickable(driver,signUpButton);
        getWebElement(signUpButton).click();

    }
    public void visibleNewUserSignupText(){
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOfElementLocated(newUserSignupText));

    }
    public void visibleEnterAccountInformation(){
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOfElementLocated(enterAccountInformationText));


    }
    public void fillTitle(){
        clickOnWebElement(titleRadioButton);

    }
    public void selectDay(){

        Select select = new Select(day);
        select.selectByIndex(2);
    }
    public void selectMonth(){

        Select select = new Select(month);
        select.selectByVisibleText("January");
    }
    public void selectYear(){

        Select select = new Select(year);
        select.selectByIndex(2);
    }
    public void newsLetterCheckBox(){
        clickOnWebElement(newletter);
    }
    public void optinCheckBox(){
        clickOnWebElement(optin);
    }
    public void enterFirsName(){
        enterText(firstName,"Hendo");
    }
    public void enterLastName(){
        enterText(lastName,"Hovhannisyan");
    }
    public void enterCOMPANY(){
        enterText(company,"ACA");
    }
    public void enterAddress1(){
        enterText(address1,"Mergelyan");
    }
    public void enterAddress2(){
        enterText(address2,"Street 7");
    }
    public void selectCountry(){
        Select select =new Select(country);
        select.selectByVisibleText("Canada");
    }
    public void enterState(){
        enterText(state,"Canada");
    }
    public void enterCity(){
        enterText(city,"Montreal");
    }
    public void enterZipcode(){
        enterText(zipcode,"ACA7852");
    }
    public void enterMobileNumber(){
        enterText(mobileNumber,"1 (438) 792-0681");
    }
    public  void createButtonClick(){
        WaitUtil.waitElementLocatedBecomeClickable(driver,creatAccountButton);
        getWebElement(creatAccountButton).click();

    }



}
